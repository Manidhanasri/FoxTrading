function getData(){



const fs=require('fs');


const access_data=JSON.parse(fs.readFileSync('src/cred.json','utf-8'));
const a_token=access_data.access_token;



var KiteTicker = require("kiteconnect").KiteTicker;
var ticker = new KiteTicker({
	api_key: "6zfi2amoxjco04yo",
	access_token:a_token
});

// console.log(ticker.access_token);

ticker.connect();
ticker.on("ticks", onTicks);
ticker.on("connect", subscribe);


const companyData = {
    256265: { name: "NIFTY 50" },
    738561:{name: "RELIANCE"},
    779521: { name: "SBIN" },
    895745: { name: "TATASTEEL" },
    2813441:{name:"RADICO"}

};

var items = [256265,738561, 779521,895745,2813441];

//data getting in onticks


 
   
   function onTicks(ticks) {
	// console.log("Ticks", ticks);

 

    for (let i = 0; i < ticks.length; i++) {
        var instrumentToken = ticks[i].instrument_token;

        var high = ticks[i].ohlc.high;
        var low = ticks[i].ohlc.low;
        var ltp = ticks[i].last_price;

        companyData[instrumentToken].high = high;
        companyData[instrumentToken].low = low;
        companyData[instrumentToken].lastTradePrice = ltp;

        if (ltp > high) {
            // console.log("buy");

            companyData[instrumentToken].status = "buy";
            companyData[instrumentToken].stoploss = low;
        } else if (ltp < low) {
            // console.log("sell");
            companyData[instrumentToken].status = "sell";
            companyData[instrumentToken].stoploss = high;
        } else {
            // console.log("stable");
            companyData[instrumentToken].status = "Hold";
            companyData[instrumentToken].stoploss = "NULL";
        }
        // console.log("companyData  :", companyData);
    }

    data = [
        {
            Nifty: companyData[items[0]],
            Reliance: companyData[items[1]],
            Sbi: companyData[items[2]],
            Tata:companyData[items[3]],
            Radico:companyData[items[4]]

        }

    ];

    fs.writeFileSync('src/stock.json',JSON.stringify(data),'utf-8');

    console.log(data);
  }

   

   function subscribe() {

	ticker.subscribe(items);
	ticker.setMode(ticker.modeFull, items);
   }

  


}
module.exports=getData;